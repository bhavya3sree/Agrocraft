<?php
echo "<script>alert('Cart Is Empty');</script>";
echo "<script>window.open('../BuyerHomepage.php','_self');</script>";

?>